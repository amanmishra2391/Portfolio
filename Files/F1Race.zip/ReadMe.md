﻿This Project is built by Aman Mishra.
This project requires Python 3.X for Operating it.
Open the folder as project and run start.py file.