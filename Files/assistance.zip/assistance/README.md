This Project is built by Aman Mishra
This folder contain the code for Assistant named JARVIS.
This folder also contains the mp3 files which are prepared during the execution of assistant.
This assistant can perform the following tasks:
    1: Shows Current time.
    2: Where is the place?
    3: Book Ola Cab from source to destination.
    4: Check weather of the place.
    5: Search on Google.
Please see JARVIS.mp3 before running this JARVIS.py.